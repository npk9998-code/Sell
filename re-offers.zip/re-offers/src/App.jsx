import { useState, useEffect, useRef } from "react";

const DIR_COLORS = {
  شمال: { bg: "#fee2e2", border: "#fca5a5", badge: "#ef4444", text: "#991b1b" },
  جنوب: { bg: "#fef9c3", border: "#fde047", badge: "#eab308", text: "#854d0e" },
  شرق:  { bg: "#dbeafe", border: "#93c5fd", badge: "#3b82f6", text: "#1e40af" },
  غرب:  { bg: "#dcfce7", border: "#86efac", badge: "#22c55e", text: "#166534" },
};

const EMPTY_FORM = {
  direction: "", neighborhood: "", sellerName: "", sellerPhone: "",
  propertyType: "", area: "", streetWidth: "", price: "", notes: "",
};

function genId() { return Date.now().toString(36) + Math.random().toString(36).slice(2); }
function fmtPrice(v) {
  const n = Number(String(v).replace(/,/g, ""));
  return isNaN(n) || v === "" ? v : n.toLocaleString("ar-SA");
}

const STORAGE_KEY = "re_offers_v2";
const INBOX_KEY   = "re_inbox_v2";

// ── helpers للتخزين المحلي ──────────────────────────────────────────────────
function lsGet(key) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : null; }
  catch { return null; }
}
function lsSet(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
}

export default function App() {
  const [tab, setTab]         = useState(0);
  const [offers, setOffers]   = useState([]);
  const [inbox, setInbox]     = useState([]);
  const [form, setForm]       = useState(EMPTY_FORM);
  const [editId, setEditId]   = useState(null);
  const [search, setSearch]   = useState("");
  const [toast, setToast]     = useState(null);
  const [delId, setDelId]     = useState(null);
  const [detailId, setDetailId] = useState(null);
  const [loaded, setLoaded]   = useState(false);
  const [filterArea, setFilterArea] = useState({ min: "", max: "" });
  const [showFilter, setShowFilter] = useState(false);
  const [filterDir, setFilterDir]   = useState("");
  const [clientForm, setClientForm] = useState(EMPTY_FORM);
  const [clientSent, setClientSent] = useState(false);
  const toastRef = useRef(null);

  // كشف التبويب من الرابط
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("tab") === "3") setTab(3);
  }, []);

  // تحميل البيانات من localStorage
  useEffect(() => {
    const savedOffers = lsGet(STORAGE_KEY);
    const savedInbox  = lsGet(INBOX_KEY);
    if (savedOffers) setOffers(savedOffers);
    if (savedInbox)  setInbox(savedInbox);
    setLoaded(true);
  }, []);

  function saveOffers(list) {
    setOffers(list);
    lsSet(STORAGE_KEY, list);
  }
  function saveInbox(list) {
    setInbox(list);
    lsSet(INBOX_KEY, list);
  }

  function toast_(msg, type = "ok") {
    clearTimeout(toastRef.current);
    setToast({ msg, type });
    toastRef.current = setTimeout(() => setToast(null), 3000);
  }

  function handleChange(e)       { setForm(f => ({ ...f, [e.target.name]: e.target.value })); }
  function handleClientChange(e) { setClientForm(f => ({ ...f, [e.target.name]: e.target.value })); }

  function handleSubmit() {
    if (!form.sellerName || !form.sellerPhone || !form.area || !form.price) {
      toast_("يرجى تعبئة الحقول المطلوبة ⚠️", "err"); return;
    }
    const next = editId
      ? offers.map(o => o.id === editId ? { ...form, id: editId } : o)
      : [{ ...form, id: genId() }, ...offers];
    saveOffers(next);
    toast_(editId ? "✅ تم التعديل" : "✅ تمت الإضافة");
    setForm(EMPTY_FORM); setEditId(null); setTab(0);
  }

  function handleClientSubmit() {
    if (!clientForm.sellerName || !clientForm.sellerPhone) {
      toast_("يرجى إدخال اسمك ورقم جوالك ⚠️", "err"); return;
    }
    const entry = { ...clientForm, id: genId(), submittedAt: new Date().toISOString() };
    const next  = [entry, ...inbox];
    saveInbox(next);
    setClientSent(true);
    setClientForm(EMPTY_FORM);
  }

  function copyClientLink() {
    // بناء الرابط الصحيح مع الـ base path
    const url = window.location.origin + window.location.pathname + "?tab=3";
    navigator.clipboard.writeText(url)
      .then(() => toast_("📋 تم نسخ الرابط! جاهز للواتساب"))
      .catch(() => toast_("⚠️ فشل النسخ التلقائي", "err"));
  }

  function approveInbox(item) {
    const { submittedAt, ...offer } = item;
    saveOffers([offer, ...offers]);
    saveInbox(inbox.filter(i => i.id !== item.id));
    toast_("✅ تم الاعتماد ونقله للرئيسية");
  }
  function rejectInbox(id) {
    saveInbox(inbox.filter(i => i.id !== id));
    toast_("🗑️ تم الرفض والحذف", "info");
  }

  function startEdit(offer) { setForm({ ...offer }); setEditId(offer.id); setTab(1); setDetailId(null); }

  function exportCSV() {
    const H = ["الاتجاه","الحي","اسم البائع","جوال البائع","نوع العقار","المساحة","عرض الشارع","السعر","ملاحظات"];
    const rows = filtered.map(o => [o.direction,o.neighborhood,o.sellerName,o.sellerPhone,o.propertyType,o.area,o.streetWidth,o.price,o.notes]);
    const csv = "\uFEFF" + [H,...rows].map(r => r.map(c => `"${(c||"").replace(/"/g,'""')}"`).join(",")).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" }));
    a.download = `عروض_عقارية_${new Date().toLocaleDateString("ar-SA").replace(/\//g,"-")}.csv`;
    a.click();
    toast_("📊 تم التصدير");
  }

  const filtered = offers.filter(o => {
    const q = search.trim();
    const matchQ   = !q || [o.sellerName,o.sellerPhone,o.direction,o.propertyType,o.neighborhood].some(v => v?.includes(q));
    const area     = parseFloat(o.area);
    const matchMin = !filterArea.min || area >= parseFloat(filterArea.min);
    const matchMax = !filterArea.max || area <= parseFloat(filterArea.max);
    const matchDir = !filterDir || o.direction === filterDir;
    return matchQ && matchMin && matchMax && matchDir;
  });

  const activeFilters = !!(filterArea.min || filterArea.max || filterDir);
  const detail        = offers.find(o => o.id === detailId);
  const isClientView  = tab === 3;

  const inp = {
    width: "100%", padding: "13px 14px", borderRadius: 12,
    border: "1.5px solid #2d3748", background: "#0d1421",
    color: "#f1f5f9", fontSize: 16, fontFamily: "Tajawal,sans-serif",
    WebkitAppearance: "none",
  };
  const clientInp = {
    width: "100%", padding: "13px 14px", borderRadius: 12,
    border: "1.5px solid #e2e8f0", background: "#fff",
    color: "#1e293b", fontSize: 16, fontFamily: "Tajawal,sans-serif",
    WebkitAppearance: "none",
  };

  return (
    <div dir="rtl" style={{ width:"100%", maxWidth:"100vw", height:"100dvh", background:isClientView?"#f8fafc":"#0f172a", fontFamily:"Tajawal,sans-serif", display:"flex", flexDirection:"column", overflow:"hidden", position:"fixed", inset:0 }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap');
        *,*::before,*::after{box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
        html,body{height:100%;overflow:hidden;position:fixed;-webkit-text-size-adjust:100%;}
        input,select,textarea{font-size:16px!important;}
        select option{background:#0d1421;color:#f1f5f9;}
        input:focus,select:focus,textarea:focus{border-color:#f59e0b!important;outline:none;box-shadow:0 0 0 3px rgba(245,158,11,.18)!important;}
        .client-inp:focus{border-color:#7c3aed!important;box-shadow:0 0 0 3px rgba(124,58,237,.18)!important;}
        .btn{border:none;border-radius:12px;padding:14px;font-size:15px;font-weight:700;cursor:pointer;font-family:Tajawal,sans-serif;transition:all .18s;touch-action:manipulation;}
        .btn-gold{background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff;}
        .btn-green{background:linear-gradient(135deg,#059669,#047857);color:#fff;}
        .btn-red{background:linear-gradient(135deg,#dc2626,#b91c1c);color:#fff;}
        .btn-purple{background:linear-gradient(135deg,#7c3aed,#6d28d9);color:#fff;}
        .btn-ghost{background:rgba(255,255,255,.06);color:#94a3b8;}
        .btn:active{transform:scale(.97);}
        .chip{display:inline-block;padding:4px 10px;border-radius:8px;font-size:12px;font-weight:700;color:#fff;}
        .row-card{border-radius:14px;padding:13px 14px;margin-bottom:10px;border-width:1.5px;border-style:solid;cursor:pointer;transition:filter .15s;touch-action:manipulation;}
        .row-card:active{filter:brightness(.9);}
        .tab-bar{display:flex;background:#0d1421;border-top:1px solid rgba(255,255,255,.08);flex-shrink:0;padding-bottom:env(safe-area-inset-bottom,0px);}
        .tab-btn{flex:1;padding:10px 0 8px;border:none;background:transparent;color:#64748b;font-size:11px;font-family:Tajawal,sans-serif;cursor:pointer;font-weight:600;border-top:2px solid transparent;transition:all .18s;touch-action:manipulation;}
        .tab-btn.active{color:#f59e0b;border-top-color:#f59e0b;}
        .overlay{position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:100;display:flex;align-items:flex-end;justify-content:center;}
        .sheet{background:#1e293b;border-radius:20px 20px 0 0;width:100%;max-width:600px;padding:24px 20px;padding-bottom:calc(24px + env(safe-area-inset-bottom,0px));max-height:88vh;overflow-y:auto;-webkit-overflow-scrolling:touch;animation:slideUp .25s ease;}
        .scroll-area{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;padding:14px 14px 8px;}
        .scroll-area::-webkit-scrollbar,.sheet::-webkit-scrollbar{display:none;}
        .scroll-area,.sheet{scrollbar-width:none;}
        .label{display:block;color:#94a3b8;font-size:13px;margin-bottom:6px;font-weight:500;}
        .label-dark{display:block;color:#475569;font-size:13px;margin-bottom:6px;font-weight:500;}
        @keyframes slideUp{from{transform:translateY(60px);opacity:0}to{transform:translateY(0);opacity:1}}
        @keyframes toastIn{from{opacity:0;transform:translate(-50%,12px)}to{opacity:1;transform:translate(-50%,0)}}
        .badge-pulse{animation:pulse 2s infinite;}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
      `}</style>

      {/* Toast */}
      {toast && (
        <div style={{ position:"fixed", top:"calc(env(safe-area-inset-top,0px) + 16px)", left:"50%", transform:"translateX(-50%)", zIndex:9999, background:toast.type==="err"?"#dc2626":toast.type==="info"?"#0ea5e9":"#16a34a", color:"#fff", padding:"11px 22px", borderRadius:12, fontWeight:700, fontSize:14, boxShadow:"0 6px 24px rgba(0,0,0,.5)", whiteSpace:"nowrap", animation:"toastIn .25s ease", maxWidth:"90vw" }}>
          {toast.msg}
        </div>
      )}

      {/* Delete Confirm */}
      {delId && (
        <div className="overlay">
          <div className="sheet" style={{ textAlign:"center" }}>
            <div style={{ fontSize:44, marginBottom:8 }}>🗑️</div>
            <div style={{ color:"#f1f5f9", fontSize:17, fontWeight:800, marginBottom:6 }}>حذف العرض؟</div>
            <div style={{ color:"#94a3b8", fontSize:13, marginBottom:24 }}>لا يمكن التراجع عن هذا الإجراء</div>
            <div style={{ display:"flex", gap:10 }}>
              <button className="btn btn-red" style={{ flex:1 }} onClick={() => { saveOffers(offers.filter(o=>o.id!==delId)); toast_("🗑️ تم الحذف","info"); setDelId(null); setDetailId(null); }}>احذف</button>
              <button className="btn btn-ghost" style={{ flex:1 }} onClick={() => setDelId(null)}>إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* Filter Sheet */}
      {showFilter && (
        <div className="overlay" onClick={() => setShowFilter(false)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <div style={{ color:"#f1f5f9", fontSize:16, fontWeight:800, marginBottom:18 }}>🔍 تصفية العروض</div>
            <label className="label">الاتجاه</label>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr 1fr", gap:8, marginBottom:16 }}>
              {["","شمال","جنوب","شرق","غرب"].map((d,i) => {
                const c   = DIR_COLORS[d];
                const sel = filterDir === d;
                return (
                  <button key={i} onClick={() => setFilterDir(d)}
                    style={{ border:`2px solid ${sel?(c?.badge||"#f59e0b"):"#2d3748"}`, background:sel?(c?.bg||"rgba(245,158,11,.15)"):"rgba(255,255,255,.03)", color:sel?(c?.text||"#f59e0b"):"#94a3b8", borderRadius:10, padding:"10px 4px", fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"Tajawal,sans-serif" }}>
                    {d || "الكل"}
                  </button>
                );
              })}
            </div>
            <label className="label">نطاق المساحة (م²)</label>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:20 }}>
              <div>
                <label className="label" style={{ fontSize:11 }}>من</label>
                <input type="number" inputMode="numeric" value={filterArea.min} onChange={e => setFilterArea(f=>({...f,min:e.target.value}))} placeholder="0" style={inp} />
              </div>
              <div>
                <label className="label" style={{ fontSize:11 }}>إلى</label>
                <input type="number" inputMode="numeric" value={filterArea.max} onChange={e => setFilterArea(f=>({...f,max:e.target.value}))} placeholder="∞" style={inp} />
              </div>
            </div>
            <div style={{ display:"flex", gap:10 }}>
              <button className="btn btn-gold" style={{ flex:2 }} onClick={() => setShowFilter(false)}>✓ تطبيق</button>
              <button className="btn btn-ghost" style={{ flex:1 }} onClick={() => { setFilterArea({min:"",max:""}); setFilterDir(""); }}>مسح</button>
            </div>
          </div>
        </div>
      )}

      {/* Detail Sheet */}
      {detail && (
        <div className="overlay" onClick={() => setDetailId(null)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            {(() => {
              const c = DIR_COLORS[detail.direction] || {};
              return (
                <>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:18 }}>
                    {detail.direction ? <span className="chip" style={{ background:c.badge, fontSize:14, padding:"5px 14px" }}>{detail.direction}</span> : <span/>}
                    <span style={{ color:"#64748b", fontSize:13 }}>{detail.propertyType || "—"}</span>
                  </div>
                  <div style={{ color:"#f1f5f9", fontSize:20, fontWeight:800, marginBottom:4 }}>{detail.sellerName}</div>
                  <div style={{ color:"#94a3b8", fontSize:15, marginBottom:18, direction:"ltr", textAlign:"right" }}>{detail.sellerPhone}</div>
                  {[
                    ["الحي",       detail.neighborhood || "-"],
                    ["المساحة",    detail.area        ? `${detail.area} م²`           : "-"],
                    ["عرض الشارع", detail.streetWidth  ? `${detail.streetWidth} م`     : "-"],
                    ["السعر",      detail.price        ? `${fmtPrice(detail.price)} ﷼` : "-"],
                    ["ملاحظات",    detail.notes || "-"],
                  ].map(([k,v]) => (
                    <div key={k} style={{ display:"flex", justifyContent:"space-between", padding:"10px 0", borderBottom:"1px solid rgba(255,255,255,.07)" }}>
                      <span style={{ color:"#64748b", fontSize:14 }}>{k}</span>
                      <span style={{ color:"#f1f5f9", fontSize:14, fontWeight:600, maxWidth:"60%", textAlign:"left" }}>{v}</span>
                    </div>
                  ))}
                  <div style={{ display:"flex", gap:10, marginTop:20 }}>
                    <button className="btn btn-gold" style={{ flex:1 }} onClick={() => startEdit(detail)}>✏️ تعديل</button>
                    <button className="btn btn-red"  style={{ flex:1 }} onClick={() => { setDelId(detail.id); setDetailId(null); }}>🗑️ حذف</button>
                  </div>
                  <button className="btn btn-ghost" style={{ width:"100%", marginTop:10 }} onClick={() => setDetailId(null)}>إغلاق</button>
                </>
              );
            })()}
          </div>
        </div>
      )}

      {/* Header */}
      {!isClientView && (
        <div style={{ background:"linear-gradient(135deg,#1e293b,#0f172a)", padding:"calc(env(safe-area-inset-top,0px) + 12px) 16px 10px", borderBottom:"1px solid rgba(245,158,11,.25)", flexShrink:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <div style={{ width:40, height:40, background:"linear-gradient(135deg,#f59e0b,#d97706)", borderRadius:12, display:"flex", alignItems:"center", justifyContent:"center", fontSize:20, flexShrink:0 }}>🏠</div>
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ color:"#f1f5f9", fontSize:16, fontWeight:800 }}>مدير عروض العقارات</div>
              <div style={{ color:"#64748b", fontSize:11, display:"flex", alignItems:"center", gap:4 }}>
                <span style={{ width:6, height:6, borderRadius:"50%", background:"#22c55e", display:"inline-block", flexShrink:0 }}/>
                <span>{offers.length} عرض • {inbox.length} وارد</span>
              </div>
            </div>
          </div>
          <div style={{ display:"flex", gap:8, marginTop:10, overflowX:"auto", paddingBottom:2, scrollbarWidth:"none" }}>
            {Object.entries(DIR_COLORS).map(([d,c]) => (
              <div key={d} style={{ flex:"0 0 auto", background:`${c.badge}22`, border:`1px solid ${c.border}`, borderRadius:10, padding:"6px 14px", textAlign:"center" }}>
                <div style={{ color:c.badge, fontSize:18, fontWeight:800 }}>{offers.filter(o=>o.direction===d).length}</div>
                <div style={{ color:"#94a3b8", fontSize:10 }}>{d}</div>
              </div>
            ))}
            <div style={{ flex:"0 0 auto", background:"rgba(124,58,237,.15)", border:"1px solid rgba(124,58,237,.3)", borderRadius:10, padding:"6px 14px", textAlign:"center" }}>
              <div style={{ color:"#a78bfa", fontSize:18, fontWeight:800 }}>{inbox.length}</div>
              <div style={{ color:"#94a3b8", fontSize:10 }}>الوارد</div>
            </div>
          </div>
        </div>
      )}

      {/* Scrollable Content */}
      <div className="scroll-area" style={{ padding: isClientView ? "20px 14px" : "14px 14px 8px" }}>

        {/* TAB 0: List */}
        {tab === 0 && !isClientView && (
          <>
            <div style={{ display:"flex", gap:8, marginBottom:10 }}>
              <div style={{ flex:1, position:"relative" }}>
                <span style={{ position:"absolute", right:12, top:"50%", transform:"translateY(-50%)", color:"#64748b", fontSize:15, pointerEvents:"none" }}>🔍</span>
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="بحث..." style={{ ...inp, paddingRight:38 }}/>
              </div>
              <button className="btn" onClick={() => setShowFilter(true)}
                style={{ padding:"0 14px", background:activeFilters?"rgba(245,158,11,.2)":"rgba(255,255,255,.06)", border:activeFilters?"1px solid #f59e0b":"1px solid transparent", color:activeFilters?"#f59e0b":"#94a3b8", fontSize:18, borderRadius:12 }}>
                ⚙️{activeFilters && <span style={{ fontSize:10, marginRight:2 }}>•</span>}
              </button>
              <button className="btn btn-green" style={{ padding:"0 12px", fontSize:12, whiteSpace:"nowrap" }} onClick={exportCSV}>📥 CSV</button>
            </div>

            {activeFilters && (
              <div style={{ background:"rgba(245,158,11,.1)", border:"1px solid rgba(245,158,11,.3)", borderRadius:10, padding:"8px 12px", marginBottom:10, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ color:"#f59e0b", fontSize:12, fontWeight:600 }}>
                  {[filterDir, filterArea.min&&`من ${filterArea.min}م²`, filterArea.max&&`إلى ${filterArea.max}م²`].filter(Boolean).join(" • ")}
                </span>
                <button onClick={() => { setFilterArea({min:"",max:""}); setFilterDir(""); }} style={{ background:"none", border:"none", color:"#f59e0b", cursor:"pointer", fontSize:14 }}>✕</button>
              </div>
            )}

            {!loaded && <div style={{ textAlign:"center", color:"#64748b", padding:"40px 0" }}>⏳ جاري التحميل...</div>}

            {loaded && filtered.length === 0 && (
              <div style={{ textAlign:"center", color:"#475569", padding:"60px 20px" }}>
                <div style={{ fontSize:48, marginBottom:12 }}>📋</div>
                <div style={{ fontSize:16, fontWeight:700, color:"#64748b" }}>{search||activeFilters?"لا نتائج":"لا توجد عروض بعد"}</div>
              </div>
            )}

            {filtered.map((o, i) => {
              const c = DIR_COLORS[o.direction] || { bg:"#f8fafc", border:"#e2e8f0", badge:"#64748b", text:"#1e293b" };
              return (
                <div key={o.id} className="row-card" style={{ background:c.bg, borderColor:c.border }} onClick={() => setDetailId(o.id)}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:6 }}>
                    <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                      {o.direction   && <span className="chip" style={{ background:c.badge, fontSize:11 }}>{o.direction}</span>}
                      {o.propertyType && <span style={{ color:c.text, fontSize:11, background:`${c.badge}22`, padding:"3px 8px", borderRadius:6, fontWeight:700 }}>{o.propertyType}</span>}
                      {o.neighborhood && <span style={{ color:"#475569", fontSize:11 }}>📍 {o.neighborhood}</span>}
                    </div>
                    <span style={{ color:"#94a3b8", fontSize:11 }}>#{i+1}</span>
                  </div>
                  <div style={{ color:c.text, fontSize:16, fontWeight:800, marginBottom:2 }}>{o.sellerName}</div>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ color:"#64748b", fontSize:12, direction:"ltr" }}>{o.sellerPhone}</span>
                    <span style={{ color:c.badge, fontSize:15, fontWeight:800 }}>{o.price ? `${fmtPrice(o.price)} ﷼` : "-"}</span>
                  </div>
                  {o.area && <div style={{ color:"#64748b", fontSize:12, marginTop:4 }}>{o.area} م² {o.streetWidth ? `• شارع ${o.streetWidth}م` : ""}</div>}
                  {o.notes && <div style={{ color:"#64748b", fontSize:11, marginTop:4, borderTop:`1px solid ${c.border}`, paddingTop:4 }}>{o.notes}</div>}
                </div>
              );
            })}
          </>
        )}

        {/* TAB 1: Add/Edit */}
        {tab === 1 && !isClientView && (
          <div style={{ paddingBottom:20 }}>
            <div style={{ color:"#f1f5f9", fontSize:16, fontWeight:800, marginBottom:18 }}>
              {editId ? "✏️ تعديل العرض" : "➕ إضافة عرض جديد"}
            </div>
            <div style={{ marginBottom:14 }}>
              <label className="label">الاتجاه</label>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
                {["شمال","جنوب","شرق","غرب"].map(d => {
                  const c = DIR_COLORS[d], sel = form.direction === d;
                  return (
                    <button key={d} onClick={() => setForm(f => ({ ...f, direction: sel ? "" : d }))}
                      style={{ border:`2px solid ${sel?c.badge:c.border}`, background:sel?c.bg:"rgba(255,255,255,.03)", color:sel?c.text:"#94a3b8", borderRadius:12, padding:"12px", fontSize:15, fontWeight:700, cursor:"pointer", fontFamily:"Tajawal,sans-serif" }}>
                      {sel?"✓ ":""}{d}
                    </button>
                  );
                })}
              </div>
            </div>
            <div style={{ marginBottom:14 }}>
              <label className="label">الحي</label>
              <input name="neighborhood" type="text" inputMode="text" value={form.neighborhood} onChange={handleChange} placeholder="مثال: حي النزهة" style={inp} autoComplete="off"/>
            </div>
            {[
              { name:"sellerName",  label:"اسم البائع *",  type:"text", ph:"مثال: محمد العمري", inputMode:"text" },
              { name:"sellerPhone", label:"جوال البائع *", type:"tel",  ph:"05xxxxxxxx",        inputMode:"tel"  },
            ].map(f => (
              <div key={f.name} style={{ marginBottom:14 }}>
                <label className="label">{f.label}</label>
                <input name={f.name} type={f.type} inputMode={f.inputMode} value={form[f.name]} onChange={handleChange} placeholder={f.ph} style={inp} autoComplete="off"/>
              </div>
            ))}
            <div style={{ marginBottom:14 }}>
              <label className="label">نوع العقار</label>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
                {["أرض","فيلا","عمارة","شقة"].map(t => (
                  <button key={t} onClick={() => setForm(f => ({ ...f, propertyType: f.propertyType===t?"":t }))}
                    style={{ border:`2px solid ${form.propertyType===t?"#f59e0b":"#2d3748"}`, background:form.propertyType===t?"rgba(245,158,11,.15)":"rgba(255,255,255,.03)", color:form.propertyType===t?"#f59e0b":"#94a3b8", borderRadius:12, padding:"12px 8px", fontSize:14, fontWeight:700, cursor:"pointer", fontFamily:"Tajawal,sans-serif" }}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:14 }}>
              <div><label className="label">المساحة (م²) *</label><input name="area" type="number" inputMode="numeric" value={form.area} onChange={handleChange} placeholder="400" style={inp}/></div>
              <div><label className="label">عرض الشارع (م)</label><input name="streetWidth" type="number" inputMode="numeric" value={form.streetWidth} onChange={handleChange} placeholder="15" style={inp}/></div>
            </div>
            <div style={{ marginBottom:14 }}>
              <label className="label">السعر المطلوب (ريال) *</label>
              <input name="price" type="text" inputMode="numeric" value={form.price} onChange={handleChange} placeholder="1,200,000" style={inp}/>
            </div>
            <div style={{ marginBottom:24 }}>
              <label className="label">ملاحظات</label>
              <textarea name="notes" value={form.notes} onChange={handleChange} placeholder="أي ملاحظات إضافية..." rows={3} style={{ ...inp, resize:"vertical" }}/>
            </div>
            <button className="btn btn-gold" style={{ width:"100%", fontSize:16, padding:"16px" }} onClick={handleSubmit}>
              {editId ? "💾 حفظ التعديل" : "✅ إضافة العرض"}
            </button>
            {editId && (
              <button className="btn btn-ghost" style={{ width:"100%", marginTop:10 }} onClick={() => { setForm(EMPTY_FORM); setEditId(null); setTab(0); }}>إلغاء</button>
            )}
          </div>
        )}

        {/* TAB 2: Inbox */}
        {tab === 2 && !isClientView && (
          <>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4 }}>
              <div style={{ color:"#f1f5f9", fontSize:16, fontWeight:800 }}>📥 صندوق الوارد</div>
              <button onClick={copyClientLink} style={{ background:"rgba(124,58,237,.2)", border:"1px solid #7c3aed", borderRadius:10, padding:"6px 12px", color:"#a78bfa", fontSize:12, fontWeight:700, cursor:"pointer", fontFamily:"Tajawal,sans-serif" }}>
                🔗 نسخ رابط العميل
              </button>
            </div>
            <div style={{ color:"#64748b", fontSize:12, marginBottom:16 }}>طلبات العملاء بانتظار اعتمادك قبل نقلها للرئيسية</div>

            {inbox.length === 0 && (
              <div style={{ textAlign:"center", color:"#475569", padding:"60px 20px" }}>
                <div style={{ fontSize:48, marginBottom:12 }}>📭</div>
                <div style={{ color:"#64748b", fontSize:15, fontWeight:700 }}>لا توجد طلبات واردة</div>
                <div style={{ color:"#475569", fontSize:12, marginTop:6 }}>انسخ الرابط من الأعلى وأرسله للعملاء لاستقبال العروض هنا</div>
              </div>
            )}

            {inbox.map(item => (
              <div key={item.id} style={{ background:"rgba(124,58,237,.08)", border:"1.5px solid rgba(124,58,237,.25)", borderRadius:14, padding:"14px", marginBottom:12 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
                  <div style={{ color:"#f1f5f9", fontSize:15, fontWeight:800 }}>{item.sellerName}</div>
                  <div style={{ color:"#64748b", fontSize:11 }}>{item.submittedAt ? new Date(item.submittedAt).toLocaleDateString("ar-SA") : ""}</div>
                </div>
                <div style={{ color:"#94a3b8", fontSize:13, marginBottom:4, direction:"ltr", textAlign:"right" }}>{item.sellerPhone}</div>
                <div style={{ display:"flex", gap:8, flexWrap:"wrap", marginBottom:10 }}>
                  {item.direction   && <span className="chip" style={{ background:DIR_COLORS[item.direction]?.badge||"#64748b", fontSize:11 }}>{item.direction}</span>}
                  {item.propertyType && <span style={{ background:"rgba(255,255,255,.1)", color:"#94a3b8", padding:"3px 8px", borderRadius:6, fontSize:11, fontWeight:700 }}>{item.propertyType}</span>}
                  {item.neighborhood && <span style={{ color:"#94a3b8", fontSize:11 }}>📍 {item.neighborhood}</span>}
                </div>
                {(item.area || item.price) && (
                  <div style={{ display:"flex", gap:16, marginBottom:10 }}>
                    {item.area  && <span style={{ color:"#94a3b8", fontSize:12 }}>{item.area} م²</span>}
                    {item.price && <span style={{ color:"#a78bfa", fontSize:13, fontWeight:700 }}>{fmtPrice(item.price)} ﷼</span>}
                  </div>
                )}
                {item.notes && <div style={{ color:"#64748b", fontSize:12, marginBottom:10 }}>{item.notes}</div>}
                <div style={{ display:"flex", gap:8 }}>
                  <button className="btn btn-green" style={{ flex:2, padding:"10px", fontSize:14 }} onClick={() => approveInbox(item)}>✅ اعتماد ونقل</button>
                  <button className="btn btn-red"   style={{ flex:1, padding:"10px", fontSize:14 }} onClick={() => rejectInbox(item.id)}>🗑️ رفض</button>
                </div>
              </div>
            ))}
          </>
        )}

        {/* TAB 3: Client Form */}
        {tab === 3 && (
          <div style={{ paddingBottom:20, maxWidth:"600px", margin:"0 auto" }}>
            {!clientSent ? (
              <>
                <div style={{ background:"linear-gradient(135deg,#7c3aed,#6d28d9)", borderRadius:16, padding:"24px 20px", marginBottom:20, textAlign:"center", boxShadow:"0 4px 15px rgba(124,58,237,0.15)" }}>
                  <div style={{ fontSize:38, marginBottom:8 }}>🏡</div>
                  <div style={{ color:"#fff", fontSize:19, fontWeight:800 }}>هل تريد عرض عقارك للبيع؟</div>
                  <div style={{ color:"rgba(255,255,255,.8)", fontSize:13, marginTop:4 }}>فضلاً أدخل البيانات المتاحة وسنتواصل معك مباشرة</div>
                </div>
                <div style={{ background:"#fff", borderRadius:16, padding:"20px", boxShadow:"0 4px 12px rgba(0,0,0,0.05)" }}>
                  <div style={{ marginBottom:14 }}>
                    <label className="label-dark">الاتجاه <span style={{ color:"#94a3b8", fontSize:11 }}>(اختياري)</span></label>
                    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
                      {["شمال","جنوب","شرق","غرب"].map(d => {
                        const c = DIR_COLORS[d], sel = clientForm.direction === d;
                        return (
                          <button key={d} onClick={() => setClientForm(f => ({ ...f, direction: sel ? "" : d }))}
                            style={{ border:`2px solid ${sel?c.badge:c.border}`, background:sel?c.bg:"#f8fafc", color:sel?c.text:"#64748b", borderRadius:12, padding:"12px", fontSize:14, fontWeight:700, cursor:"pointer", fontFamily:"Tajawal,sans-serif" }}>
                            {sel?"✓ ":""}{d}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div style={{ marginBottom:14 }}>
                    <label className="label-dark">الحي / الموقع <span style={{ color:"#94a3b8", fontSize:11 }}>(اختياري)</span></label>
                    <input name="neighborhood" type="text" inputMode="text" className="client-inp" value={clientForm.neighborhood} onChange={handleClientChange} placeholder="مثال: حي النزهة" style={clientInp} autoComplete="off"/>
                  </div>
                  <div style={{ marginBottom:14 }}>
                    <label className="label-dark">اسمك الكريم *</label>
                    <input name="sellerName" type="text" inputMode="text" className="client-inp" value={clientForm.sellerName} onChange={handleClientChange} placeholder="الاسم الثنائي أو الثلاثي" style={clientInp} autoComplete="off"/>
                  </div>
                  <div style={{ marginBottom:14 }}>
                    <label className="label-dark">رقم الجوال *</label>
                    <input name="sellerPhone" type="tel" inputMode="tel" className="client-inp" value={clientForm.sellerPhone} onChange={handleClientChange} placeholder="05xxxxxxxx" style={clientInp} autoComplete="off"/>
                  </div>
                  <div style={{ marginBottom:14 }}>
                    <label className="label-dark">نوع العقار <span style={{ color:"#94a3b8", fontSize:11 }}>(اختياري)</span></label>
                    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
                      {["أرض","فيلا","عمارة"].map(t => {
                        const sel = clientForm.propertyType === t;
                        return (
                          <button key={t} onClick={() => setClientForm(f => ({ ...f, propertyType: sel ? "" : t }))}
                            style={{ border:`2px solid ${sel?"#7c3aed":"#e2e8f0"}`, background:sel?"#ede9fe":"#f8fafc", color:sel?"#7c3aed":"#64748b", borderRadius:12, padding:"12px 8px", fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"Tajawal,sans-serif" }}>
                            {t}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:14 }}>
                    <div><label className="label-dark">المساحة (م²)</label><input name="area" type="number" inputMode="numeric" value={clientForm.area} onChange={handleClientChange} placeholder="400" style={clientInp}/></div>
                    <div><label className="label-dark">عرض الشارع (م)</label><input name="streetWidth" type="number" inputMode="numeric" value={clientForm.streetWidth} onChange={handleClientChange} placeholder="15" style={clientInp}/></div>
                  </div>
                  <div style={{ marginBottom:14 }}>
                    <label className="label-dark">السعر المطلوب أو السوم (ريال)</label>
                    <input name="price" type="text" inputMode="numeric" value={clientForm.price} onChange={handleClientChange} placeholder="1,200,000" style={clientInp}/>
                  </div>
                  <div style={{ marginBottom:20 }}>
                    <label className="label-dark">ملاحظات إضافية</label>
                    <textarea name="notes" value={clientForm.notes} onChange={handleClientChange} placeholder="أي تفاصيل أخرى..." rows={3} style={{ ...clientInp, resize:"vertical" }}/>
                  </div>
                  <button className="btn btn-purple" style={{ width:"100%", fontSize:16, padding:"16px" }} onClick={handleClientSubmit}>
                    📤 إرسال العرض العقاري
                  </button>
                </div>
              </>
            ) : (
              <div style={{ textAlign:"center", padding:"80px 20px" }}>
                <div style={{ fontSize:64, marginBottom:16 }}>✅</div>
                <div style={{ color:"#1e293b", fontSize:20, fontWeight:800, marginBottom:8 }}>تم إرسال طلبك بنجاح!</div>
                <div style={{ color:"#64748b", fontSize:14, marginBottom:28 }}>تم حفظ بيانات العقار، وسنتواصل معك قريباً.</div>
                <button className="btn btn-purple" style={{ padding:"14px 40px" }} onClick={() => setClientSent(false)}>
                  إرسال عرض آخر
                </button>
              </div>
            )}
          </div>
        )}

      </div>

      {/* Tab Bar */}
      {!isClientView && (
        <div className="tab-bar">
          {[
            { i:0, icon:"📋", label:"العروض"  },
            { i:1, icon:"➕", label:"إضافة"   },
            { i:2, icon:"📥", label:"الوارد", badge: inbox.length },
          ].map(({ i, icon, label, badge }) => (
            <button key={i} className={`tab-btn${tab===i?" active":""}`} onClick={() => tab===1&&editId&&i!==1?null:setTab(i)}>
              <div style={{ position:"relative", display:"inline-block" }}>
                <span style={{ fontSize:19 }}>{icon}</span>
                {badge > 0 && (
                  <span style={{ position:"absolute", top:-4, right:-8, background:"#ef4444", color:"#fff", fontSize:9, fontWeight:800, borderRadius:"50%", width:16, height:16, display:"flex", alignItems:"center", justifyContent:"center" }} className="badge-pulse">{badge}</span>
                )}
              </div>
              <div style={{ marginTop:1 }}>{label}</div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
